
<?php $__env->startSection('content'); ?>
    <div class="main-body">

        <section class="blog-page-wrap section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 col-md-10 offset-lg-1 offset-md-1 col-12">
                        <div class="blog-post-details ml-lg-2">
                            <div class="blog-item post aos-init aos-animate" data-aos="fade-up" data-aos-duration="700"
                                data-aos-delay="100">
                                <div class="featured-thumb">
                                    <img src="<?php echo e(asset('/')); ?>images/<?php echo e($blog->image); ?>" alt="">
                                </div>
                                <div class="post-date">
                                    <div class="date"><?php echo e($blog->created_at); ?></div>
                                </div>

                                <div class="post-content">
                                    <h3><?php echo e($blog->title); ?></h3>

                                    <blockquote>

                                        <?php echo e($blog->detail); ?>

                                    </blockquote>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grid\resources\views/front/pages/view_blogs.blade.php ENDPATH**/ ?>