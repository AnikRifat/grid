
<?php $__env->startSection('content'); ?>
    <!-- /.card -->
    <?php if($massage = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h5><i class="icon fas fa-check"></i> Succwss!</h5>
            <?php echo e($massage); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">View Blogs</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Details</th>
                        <th>image</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->detail); ?></td>
                            <td><img src="images/<?php echo e($item->image); ?>" height="100" alt="noimage"></td>
                            <td>
                                <form action="<?php echo e(url('admin/blogs/destroy', $item->id)); ?>" method="post">
                                    <a href="<?php echo e(url('admin/blogs/edit', $item->id)); ?>" class="btn btn-app bg-info">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('Delete'); ?>
                                    <button type="submit" class="btn btn-app bg-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>

                                </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>

            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grid\resources\views/admin/pages/blogs/index.blade.php ENDPATH**/ ?>