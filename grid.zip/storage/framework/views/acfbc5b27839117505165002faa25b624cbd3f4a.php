<?php echo $__env->make('admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-Content">
    <!-- content will start here.. -->



    start mudfk

    <!-- content will end here.. -->

</div>
<?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\grid\resources\views/admin/home.blade.php ENDPATH**/ ?>