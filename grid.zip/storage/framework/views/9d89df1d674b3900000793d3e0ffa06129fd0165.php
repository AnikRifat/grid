<?php echo $__env->make('admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-Content">
    <!-- content will start here.. -->


    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>

        <!-- content will end here.. -->
    </div>
</div>
<?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\grid\resources\views/admin/master/app.blade.php ENDPATH**/ ?>