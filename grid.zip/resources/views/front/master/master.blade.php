@include('front.inc.header')
@yield('content')
@include('front.inc.footer')
