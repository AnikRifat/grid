@include('admin.inc.header')

<div class="main-Content">
    <!-- content will start here.. -->


    <div class="container">
        @yield('content')

        <!-- content will end here.. -->
    </div>
</div>
@include('admin.inc.footer')
